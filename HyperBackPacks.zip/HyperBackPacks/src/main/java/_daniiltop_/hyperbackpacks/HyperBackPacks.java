package _daniiltop_.hyperbackpacks;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class HyperBackPacks extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        this.getCommand("backpack").setExecutor(this);
        saveDefaultConfig();
        createBackupFolder();
    }

    // Метод для создания папки для бэкапов, если её нет
    private void createBackupFolder() {
        File backupFolder = new File(getDataFolder(), getConfig().getString("backup-folder", "backups"));
        if (!backupFolder.exists()) backupFolder.mkdirs();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Проверка на наличие пермишена backpacks.create
        if (!sender.hasPermission("backpacks.create")) {
            sender.sendMessage(getConfig().getString("messages.no-permission").replace("&", "§"));
            return true;
        }

        if (args.length < 1 || !args[0].equalsIgnoreCase("create")) {
            sender.sendMessage(getConfig().getString("messages.syntax-error").replace("&", "§"));
            return true;
        }

        File backupFolder = new File(getDataFolder(), getConfig().getString("backup-folder", "backups"));
        String fileExtension = getConfig().getString("backup-extension", ".zip");

        try {
            if (args.length == 2 && args[1].equalsIgnoreCase("all")) {
                String backupName = generateBackupName("server_backup", fileExtension);
                createBackup(new File(getServer().getWorldContainer(), "."), new File(backupFolder, backupName));
                sender.sendMessage(getConfig().getString("messages.backup-all-success").replace("&", "§"));
            } else if (args.length == 2) {
                String folderName = args[1];
                File targetFolder = new File(getServer().getWorldContainer(), folderName);
                if (targetFolder.exists() && targetFolder.isDirectory()) {
                    String backupName = generateBackupName(folderName + "_backup", fileExtension);
                    createBackup(targetFolder, new File(backupFolder, backupName));
                    sender.sendMessage(getConfig().getString("messages.backup-folder-success").replace("{folder}", folderName).replace("&", "§"));
                } else {
                    sender.sendMessage(getConfig().getString("messages.folder-not-found").replace("{folder}", folderName).replace("&", "§"));
                }
            } else {
                sender.sendMessage(getConfig().getString("messages.syntax-error").replace("&", "§"));
            }
        } catch (IOException e) {
            sender.sendMessage(getConfig().getString("messages.backup-error").replace("&", "§"));
            e.printStackTrace();
        }

        return true;
    }

    private String generateBackupName(String baseName, String extension) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.HH.mm.dd.MM.yyyy");
        String date = dateFormat.format(new Date());
        return baseName + "_" + date + extension;
    }

    private void createBackup(File sourceFolder, File zipFile) throws IOException {
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            zipFolder(sourceFolder.toPath(), sourceFolder.toPath(), zos);
        }
    }

    private void zipFolder(Path rootPath, Path sourcePath, ZipOutputStream zos) throws IOException {
        Files.walk(sourcePath).forEach(path -> {
            try {
                String zipEntryName = rootPath.relativize(path).toString();
                if (Files.isDirectory(path)) {
                    if (!zipEntryName.isEmpty()) {
                        zos.putNextEntry(new ZipEntry(zipEntryName + "/"));
                        zos.closeEntry();
                    }
                } else {
                    zos.putNextEntry(new ZipEntry(zipEntryName));
                    Files.copy(path, zos);
                    zos.closeEntry();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
